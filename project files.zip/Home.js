import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>Welcome to anony</h1>
            <p>Your platform for anonymous articles.</p>
        </div>
    );
};

export default Home;
