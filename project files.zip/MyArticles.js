import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import MyArticleCard from './MyArticleCard';

const MyArticles = () => {
    const [articles, setArticles] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchMyArticles = async () => {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.get('http://localhost:5000/api/my-articles', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setArticles(response.data);
            } catch (err) {
                console.error('Error fetching articles:', err);
            } finally {
                setLoading(false);
            }
        };

        fetchMyArticles();
    }, []);

    const handleEdit = (articleId) => {
        navigate(`/edit-article/${articleId}`);
    };

    const handleView = (articleId) => {
        navigate(`/article/${articleId}`); // Navigate to the full article page
    };

    const handleDelete = async (articleId) => {
        if (window.confirm('Are you sure you want to delete this article?')) {
            const token = localStorage.getItem('token'); // Retrieve the token from localStorage
            if (!token) {
                alert('You are not authorized to delete this article. Please log in.');
                return;
            }
    
            try {
                const response = await axios.delete(`http://localhost:5000/api/articles/${articleId}`, {
                    headers: {
                        Authorization: `Bearer ${token}` // Include the token in the headers
                    }
                });
                console.log('Delete response:', response.data); // Log the response from the server
                if (response.status === 200) {
                    // Remove the deleted article from state
                    setArticles(articles.filter(article => article._id !== articleId));
                } else {
                    console.error('Failed to delete article:', response.data);
                    alert('Failed to delete article. Please try again.');
                }
            } catch (err) {
                console.error('Error deleting article:', err);
                alert('Error deleting article. Please try again later.');
            }
        }
    };

    if (loading) return <p>Loading your articles...</p>;

    return (
        <div>
            <h2>My Articles</h2>
            {articles.length === 0 ? (
                <p>You have not posted any articles yet.</p>
            ) : (
                articles.map((article) => (
                    <MyArticleCard 
                        key={article._id} 
                        article={article} 
                        onEdit={() => handleEdit(article._id)} 
                        onDelete={() => handleDelete(article._id)} 
                        onView={() => handleView(article._id)} // Pass the handleView function
                    />
                ))
            )}
        </div>
    );
};

export default MyArticles;