import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types'; // Import PropTypes for prop validation
import '../styles/Navbar.css';

const Navbar = ({ isAuthenticated }) => {
    const [query, setQuery] = useState(''); // Store search query
    const navigate = useNavigate(); // For navigation

    const handleSearch = (e) => {
        e.preventDefault();
        if (!query.trim()) {
            alert('Please enter a search term.'); // Provide feedback for empty search
            return;
        }
        navigate(`/search?query=${query.trim()}`); // Trim query and navigate
    };

    return (
        <div className="navbar">
            <Link to="/" className="logo" aria-label="Home">
                anony
            </Link> {/* Logo as a clickable link */}
            <form onSubmit={handleSearch} className="search-form"> {/* Add class for styling */}
                <input
                    type="text"
                    placeholder="Search articles..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)} // Update the query state
                    aria-label="Search articles" // Accessibility improvement
                />
                <button type="submit" aria-label="Submit search">Search</button>
            </form>
            <div className="nav-links">
                <Link to="/" className="nav-link" aria-label="Go to Home">Home</Link>
                <Link to="/articles" className="nav-link" aria-label="View Articles">Articles</Link>
                <Link to="/about" className="nav-link" aria-label="Learn About Us">About</Link>
                {isAuthenticated ? (
                    <Link to="/dashboard" className="nav-link" aria-label="Go to Dashboard">Dashboard</Link>
                ) : (
                    <>
                        <Link to="/login" className="nav-link" aria-label="Login">Login</Link>
                        <Link to="/register" className="nav-link" aria-label="Register">Register</Link>
                    </>
                )}
            </div>
        </div>
    );
};

// Prop validation for better type checking
Navbar.propTypes = {
    isAuthenticated: PropTypes.bool.isRequired,
};

export default Navbar;
